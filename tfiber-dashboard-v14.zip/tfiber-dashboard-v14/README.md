# T-Fiber End-User Connectivity Dashboard

React 18 + Highcharts 11, built with Vite. Frontend only: data is read from static JSON in `public/data/`.

## Run
    npm install
    npm start          # http://localhost:3000 (same as npm run dev)
    npm run build      # static site in dist/ (any static host)
    npm run preview

## Structure
    public/data/connections.json        full export: 12,626 records (columnar; no contact details)
    public/data/summary_reference.json  figures from 'Summary 16-Sep-2026'
    src/config.js        data paths, scope, SAC "received" statuses, Top-N values, filter list
    src/lib/mapper.js    original column names (incl. "Connection Catogory"), cleaning, alias tables
    src/lib/calc.js      filters, KPI rules, chart aggregation (pure functions)
    src/hooks.js         data loading (replace with an API call later; nothing else changes)
    src/components/      MultiSelect, KpiCard, ChartCard, DataTable, Highcharts charts (charts.jsx)
    tools/excel_to_json.py   workbook -> connections.json

## Records tab
Filter by ONT Serial Number, OLT IP Address, Service ID, GI / GP Name, GP/GI ONT LGD Code and PO Num (text, partial match;
comma-separated values match any). It also respects the global filters. Export CSV / Excel / PDF downloads every matching row
(PDF is capped at 3,000 rows). The export libraries load only when Export is used.

## Refresh data
    pip install pandas openpyxl
    python tools/excel_to_json.py "<workbook>.xlsx" --out public/data/connections.json --columnar

## KPI rules
With the "PO only" switch they match 'Summary 16-Sep-2026':
- Lit-Up = PO and Litup Yes; Yet to Lit-Up = PO and Litup No/blank
- Service Provisioned = PO, Lit-Up, and (Yes or Disconnected); Service Yet to Provision = Lit-Up minus Provisioned
- Disconnected = PO and Disconnection Status Yes
- "POS" in the brief is treated as POC.

## Open item
SAC Form Received computes to 1,600 vs 1,606 in the summary (yet to receive 1,454 vs 1,448). The summary seems to
include a manual adjustment; the business team must confirm which statuses count as received (`sacReceived` in `src/config.js`).
