import { useMemo, useState } from 'react';
import { fmt } from '../lib/theme';

/** Ranked table with a Lit-Up rate bar. Used for districts and operators. */
export default function DataTable({ rows, nameLabel, searchPlaceholder, maxHeight = 460 }) {
  const [q, setQ] = useState('');
  const shown = useMemo(() => {
    const t = q.trim().toLowerCase();
    return t ? rows.filter((r) => r.name.toLowerCase().includes(t)) : rows;
  }, [rows, q]);
  return (
    <div>
      <div className="table-tools">
        <input className="search" placeholder={searchPlaceholder} value={q} onChange={(e) => setQ(e.target.value)} />
        <span className="muted">{fmt(shown.length)} of {fmt(rows.length)}</span>
      </div>
      <div className="table-wrap" style={{ maxHeight }}>
        <table>
          <thead><tr><th>{nameLabel}</th><th>Total</th><th>Lit-Up</th><th className="rate-col">Lit-Up rate</th></tr></thead>
          <tbody>
            {shown.map((r) => {
              const rate = r.total ? (r.lit / r.total) * 100 : 0;
              return (
                <tr key={r.name}>
                  <td>{r.name}</td><td>{fmt(r.total)}</td><td>{fmt(r.lit)}</td>
                  <td className="rate-col"><div className="rate"><div className="meter"><i style={{ width: `${rate}%` }} /></div><span>{rate.toFixed(0)}%</span></div></td>
                </tr>
              );
            })}
            {shown.length === 0 && <tr><td colSpan="4" className="muted">No matches.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
