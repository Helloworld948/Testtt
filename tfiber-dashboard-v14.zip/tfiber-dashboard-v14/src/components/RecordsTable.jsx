import { useDeferredValue, useEffect, useMemo, useRef, useState } from 'react';
import { RECORD_COLUMNS, FIELD_FILTERS, cell } from '../lib/recordColumns';
import { exportCsv, exportPdf, exportXlsx, PDF_MAX_ROWS } from '../lib/export';
import { fmt } from '../lib/theme';

const PLACEHOLDER = /^(not available|not applicable|na|n\/a|#n\/a|-|need to update|yet to connect|pending|household)$/i;
const isReal = (v) => v !== '' && !PLACEHOLDER.test(v);
const TABLE_COLS = RECORD_COLUMNS.filter((c) => c.table);
const PILL = { Yes: 'good', No: 'warn', Blank: 'warn', Disconnected: 'bad', PO: 'po', POC: 'poc' };
const EMPTY_FIELDS = Object.fromEntries(FIELD_FILTERS.map((f) => [f.key, '']));
const terms = (s) => s.split(/[,\n]/).map((t) => t.trim().toLowerCase()).filter(Boolean);

export default function RecordsTable({ rows, context }) {
  const [fields, setFields] = useState(EMPTY_FIELDS);
  const [quick, setQuick] = useState('');
  const [sort, setSort] = useState({ key: null, dir: 1 });
  const [page, setPage] = useState(0);
  const [size, setSize] = useState(25);
  const [menu, setMenu] = useState(false);
  const [busy, setBusy] = useState('');
  const [msg, setMsg] = useState('');
  const menuRef = useRef(null);

  const dFields = useDeferredValue(fields);
  const dQuick = useDeferredValue(quick);

  const matched = useMemo(() => {
    const active = FIELD_FILTERS.map((f) => [f.key, terms(dFields[f.key])]).filter(([, t]) => t.length);
    const q = dQuick.trim().toLowerCase();
    if (!active.length && !q) return rows;
    return rows.filter((r) => {
      for (const [k, t] of active) {
        const v = cell(r, k).toLowerCase();
        if (!t.some((x) => v.includes(x))) return false;
      }
      return !q || TABLE_COLS.some((c) => cell(r, c.key).toLowerCase().includes(q));
    });
  }, [rows, dFields, dQuick]);

  const sorted = useMemo(() => {
    if (!sort.key) return matched;
    const k = sort.key;
    return [...matched].sort((a, b) => cell(a, k).localeCompare(cell(b, k), undefined, { numeric: true, sensitivity: 'base' }) * sort.dir);
  }, [matched, sort]);

  useEffect(() => { setPage(0); }, [rows, dFields, dQuick, size, sort]);
  useEffect(() => {
    if (!menu) return undefined;
    const onDoc = (e) => { if (menuRef.current && !menuRef.current.contains(e.target)) setMenu(false); };
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, [menu]);

  const pages = Math.max(1, Math.ceil(sorted.length / size));
  const cur = Math.min(page, pages - 1);
  const view = sorted.slice(cur * size, cur * size + size);
  const activeCount = FIELD_FILTERS.filter((f) => terms(fields[f.key]).length).length + (quick.trim() ? 1 : 0);

  const stats = useMemo(() => ({
    olts: new Set(matched.map((r) => r.olt).filter(isReal)).size,
    ont: matched.filter((r) => isReal(r.ont)).length,
    sid: matched.filter((r) => isReal(r.sid)).length,
    pos: new Set(matched.map((r) => r.ponum).filter(isReal)).size,
  }), [matched]);

  const tableFilterText = [
    ...FIELD_FILTERS.filter((f) => terms(fields[f.key]).length).map((f) => `${f.label} = ${fields[f.key].trim()}`),
    ...(quick.trim() ? [`Search = ${quick.trim()}`] : []),
  ].join('; ');

  const run = async (kind) => {
    setMenu(false); setMsg(''); setBusy(kind);
    try {
      if (kind === 'csv') exportCsv(sorted, RECORD_COLUMNS);
      else if (kind === 'xlsx') await exportXlsx(sorted, RECORD_COLUMNS);
      else {
        const info = await exportPdf(sorted, RECORD_COLUMNS.filter((c) => c.pdf), { title: 'T-Fiber Connectivity · Records', subtitle: `${context}${tableFilterText ? ` · Table filters: ${tableFilterText}` : ''}` });
        if (info.capped) setMsg(`PDF holds the first ${fmt(info.used)} of ${fmt(info.total)} records. Use CSV or Excel for the full list.`);
      }
    } catch (e) {
      setMsg(`Export failed: ${e.message}`);
    } finally { setBusy(''); }
  };

  const setField = (k, v) => setFields((p) => ({ ...p, [k]: v }));
  const clear = () => { setFields(EMPTY_FIELDS); setQuick(''); };
  const toggleSort = (k) => setSort((s) => (s.key !== k ? { key: k, dir: 1 } : s.dir === 1 ? { key: k, dir: -1 } : { key: null, dir: 1 }));

  return (
    <section className="card records">
      <header className="card-head">
        <h2>Records</h2>
        <div className="rec-actions">
          <input className="search" placeholder="Search all columns…" value={quick} onChange={(e) => setQuick(e.target.value)} />
          <div className="menu-wrap" ref={menuRef}>
            <button className="btn primary" disabled={!sorted.length || !!busy} onClick={() => setMenu((m) => !m)} aria-expanded={menu}>
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3v12M7 10l5 5 5-5M4 20h16" /></svg>
              {busy ? 'Preparing…' : `Export ${fmt(sorted.length)}`}
            </button>
            {menu && (
              <div className="menu" role="menu">
                <button role="menuitem" onClick={() => run('csv')}><b>CSV</b><span>All columns · opens in Excel</span></button>
                <button role="menuitem" onClick={() => run('xlsx')}><b>Excel (.xlsx)</b><span>All columns · IDs kept as text</span></button>
                <button role="menuitem" onClick={() => run('pdf')}><b>PDF</b><span>Key columns · up to {fmt(PDF_MAX_ROWS)} rows</span></button>
              </div>
            )}
          </div>
        </div>
      </header>

      <div className="rec-filters">
        {FIELD_FILTERS.map((f) => (
          <label key={f.key} className={terms(fields[f.key]).length ? 'on' : ''}>
            <span>{f.label}</span>
            <input value={fields[f.key]} placeholder={f.placeholder} onChange={(e) => setField(f.key, e.target.value)} spellCheck={false} />
          </label>
        ))}
        <button className="btn ghost" disabled={!activeCount} onClick={clear}>Clear{activeCount ? ` (${activeCount})` : ''}</button>
      </div>
      <p className="rec-hint">Separate several values with a comma to match any of them.</p>

      <div className="rec-stats">
        <div><b>{fmt(matched.length)}</b><span>Matching records</span></div>
        <div><b>{fmt(stats.pos)}</b><span>Distinct PO numbers</span></div>
        <div><b>{fmt(stats.olts)}</b><span>Distinct OLT IPs</span></div>
        <div><b>{fmt(stats.ont)}</b><span>With ONT serial</span></div>
        <div><b>{fmt(stats.sid)}</b><span>With Service ID</span></div>
      </div>

      {msg && <div className="notice slim">{msg}</div>}

      <div className="table-wrap rec-wrap">
        <table className="rec">
          <thead>
            <tr>
              {TABLE_COLS.map((c) => (
                <th key={c.key} onClick={() => toggleSort(c.key)} aria-sort={sort.key === c.key ? (sort.dir === 1 ? 'ascending' : 'descending') : 'none'}>
                  {c.label}<span className="sort">{sort.key === c.key ? (sort.dir === 1 ? '▲' : '▼') : ''}</span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {view.map((r, i) => (
              <tr key={`${cur}-${i}`}>
                {TABLE_COLS.map((c) => {
                  const v = cell(r, c.key);
                  if (c.pill || c.key === 'po') return <td key={c.key}>{v ? <span className={`pill-s ${PILL[v] || 'neutral'}`}>{v}</span> : <span className="ph">—</span>}</td>;
                  return <td key={c.key} className={!v || PLACEHOLDER.test(v) ? 'ph' : ''} title={v}>{v || '—'}</td>;
                })}
              </tr>
            ))}
            {view.length === 0 && <tr><td colSpan={TABLE_COLS.length} className="no-rows">No records match these filters.</td></tr>}
          </tbody>
        </table>
      </div>

      <footer className="pager">
        <span className="muted">
          {sorted.length ? `${fmt(cur * size + 1)}–${fmt(Math.min(sorted.length, cur * size + size))} of ${fmt(sorted.length)}` : '0 records'}
        </span>
        <div className="pager-ctl">
          <label>Rows <select value={size} onChange={(e) => setSize(+e.target.value)}>{[25, 50, 100, 200].map((n) => <option key={n}>{n}</option>)}</select></label>
          <button className="btn sm" disabled={cur === 0} onClick={() => setPage(0)}>«</button>
          <button className="btn sm" disabled={cur === 0} onClick={() => setPage(cur - 1)}>‹ Prev</button>
          <span className="page-no">Page {fmt(cur + 1)} / {fmt(pages)}</span>
          <button className="btn sm" disabled={cur >= pages - 1} onClick={() => setPage(cur + 1)}>Next ›</button>
          <button className="btn sm" disabled={cur >= pages - 1} onClick={() => setPage(pages - 1)}>»</button>
        </div>
      </footer>
    </section>
  );
}
