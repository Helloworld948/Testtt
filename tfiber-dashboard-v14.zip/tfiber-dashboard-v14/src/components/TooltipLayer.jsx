import { useEffect, useLayoutEffect, useRef, useState } from 'react';

/**
 * One tooltip for the whole app. It reads data-tip from the hovered/focused element, is drawn on top of
 * everything (position: fixed, highest z-index) and is kept inside the window, so it never hides behind
 * or collides with neighbouring cards.
 */
export default function TooltipLayer() {
  const [tip, setTip] = useState(null); // { text, rect }
  const [pos, setPos] = useState({ left: 0, top: 0, ready: false });
  const box = useRef(null);

  useEffect(() => {
    const show = (e) => {
      const el = e.target.closest ? e.target.closest('[data-tip]') : null;
      if (el) setTip({ text: el.getAttribute('data-tip'), rect: el.getBoundingClientRect() }); else setTip(null);
    };
    const hide = () => setTip(null);
    document.addEventListener('mouseover', show);
    document.addEventListener('focusin', show);
    document.addEventListener('focusout', hide);
    document.addEventListener('mousedown', hide);
    window.addEventListener('scroll', hide, true);
    return () => {
      document.removeEventListener('mouseover', show); document.removeEventListener('focusin', show);
      document.removeEventListener('focusout', hide); document.removeEventListener('mousedown', hide);
      window.removeEventListener('scroll', hide, true);
    };
  }, []);

  useLayoutEffect(() => {
    if (!tip || !box.current) { setPos((p) => (p.ready ? { ...p, ready: false } : p)); return; }
    const { width: w, height: h } = box.current.getBoundingClientRect();
    const r = tip.rect, m = 10;
    let left = r.left + r.width / 2 - w / 2;
    left = Math.max(m, Math.min(left, window.innerWidth - w - m));
    let top = r.bottom + 8;
    if (top + h > window.innerHeight - m) top = Math.max(m, r.top - h - 8);
    setPos({ left, top, ready: true });
  }, [tip]);

  if (!tip) return null;
  return (
    <div ref={box} className="tip" role="tooltip" style={{ left: pos.left, top: pos.top, visibility: pos.ready ? 'visible' : 'hidden' }}>
      {tip.text}
    </div>
  );
}
