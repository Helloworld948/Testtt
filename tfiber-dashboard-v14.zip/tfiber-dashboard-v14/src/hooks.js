import { useEffect, useState } from 'react';
import { config } from './config';
import { loadRecords } from './lib/mapper';

/** Loads the static JSON files (no backend). Swap the URLs in config.js for another data source later. */
export function useDashboardData() {
  const [state, setState] = useState({ status: 'loading' });
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [dataRes, refRes] = await Promise.all([fetch(config.dataUrl, { cache: 'no-cache' }), fetch(config.referenceUrl, { cache: 'no-cache' })]);
        if (!dataRes.ok) throw new Error(`Could not load ${config.dataUrl} (${dataRes.status})`);
        const data = loadRecords(await dataRes.json(), config);
        const reference = refRes.ok ? await refRes.json() : null;
        if (!cancelled) setState({ status: 'ready', ...data, reference });
      } catch (e) {
        if (!cancelled) setState({ status: 'error', message: e.message });
      }
    })();
    return () => { cancelled = true; };
  }, []);
  return state;
}
