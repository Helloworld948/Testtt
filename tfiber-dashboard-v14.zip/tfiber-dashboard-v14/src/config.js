// Dashboard settings. Edit here; no other file needs to change.
export const APP_VERSION = 'v1.4 · Records table on Overview';

export const config = {
  dataUrl: 'data/connections.json', // array of records, or { columns, rows }
  referenceUrl: 'data/summary_reference.json', // figures from 'Summary 16-Sep-2026'
  asOfLabel: '16 Sep 2026',

  // Scope: only these records are used by the dashboard
  scopeCategories: ['Household', 'Private Enterprise', 'GI-Enterprise'],
  scopePoStatus: ['PO', 'POC'],

  // SAC Form Status values that count as "received" (business team must confirm)
  sacReceived: ['Available', 'Over E-mail', 'Completed'],

  // Operator chart: show this many operators, group the rest as "Others"
  operatorTopN: 10,
  districtTopN: 15,
};

export const FILTERS = [
  { key: 'cat', label: 'Connection Category' },
  { key: 'dept', label: 'Department' },
  { key: 'po', label: 'PO Status' },
  { key: 'lco', label: 'LCO / MSI / TSP' },
  { key: 'sol', label: 'Solution Type' },
  { key: 'mode', label: 'Delivery Mode' },
  { key: 'district', label: 'District' },
  { key: 'pkg', label: 'Package' },
  { key: 'op', label: 'LCO Operator' },
];
