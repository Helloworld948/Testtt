import { useCallback, useMemo, useState } from 'react';
import { config, FILTERS } from './config';
import { useDashboardData } from './hooks';
import { aggregate, applyFilters, computeKpis, facets } from './lib/calc';
import { fmt, STATUS } from './lib/theme';
import MultiSelect from './components/MultiSelect';
import KpiCard from './components/KpiCard';
import ChartCard from './components/ChartCard';
import DataTable from './components/DataTable';
import RecordsTable from './components/RecordsTable';
import TooltipLayer from './components/TooltipLayer';
import { ColumnChart, DonutChart, HBarChart, LitStackChart, PipelineChart, PoStackColumn } from './components/charts';

const EMPTY = Object.fromEntries(FILTERS.map((f) => [f.key, []]));
const sacSet = new Set(config.sacReceived);
const TABS = ['Overview', 'Geography', 'Operators', 'Records', 'Validation'];
const PO_COLORS = [STATUS.po, STATUS.poc];
const pct = (a, b) => (b ? (a / b) * 100 : null);

export default function App() {
  const data = useDashboardData();
  if (data.status === 'loading') return <div className="state">Loading dashboard…</div>;
  if (data.status === 'error') {
    return <div className="state error"><h2>Could not load data</h2><p>{data.message}</p><p>Run <code>npm start</code> instead of opening index.html directly.</p></div>;
  }
  return <Dashboard {...data} />;
}

function Dashboard({ rows, excluded, totalSource, reference, missingColumns }) {
  const [filters, setFilters] = useState(EMPTY);
  const [basis, setBasis] = useState('po');
  const [tab, setTab] = useState('Overview');
  const [showFilters, setShowFilters] = useState(false);

  const options = useMemo(() => facets(rows), [rows]);
  const filtered = useMemo(() => applyFilters(rows, filters), [rows, filters]);
  const kpi = useMemo(() => computeKpis(filtered, basis, sacSet), [filtered, basis]);
  const agg = useMemo(() => aggregate(filtered), [filtered]);

  const activeChips = FILTERS.flatMap((f) => filters[f.key].map((v) => ({ key: f.key, label: f.label, value: v })));
  const hasFilters = activeChips.length > 0;
  const setFilter = useCallback((key, vals) => setFilters((p) => ({ ...p, [key]: vals })), []);
  const toggleValue = useCallback((key, value) => setFilters((p) => ({
    ...p, [key]: p[key].includes(value) ? p[key].filter((x) => x !== value) : [...p[key], value],
  })), []);
  const pick = (key) => (v) => { if (v !== 'Others') toggleValue(key, v); };
  const pickers = useMemo(() => ({
    district: pick('district'), pkg: pick('pkg'), cat: pick('cat'), po: pick('po'), op: pick('op'),
    sol: pick('sol'), mode: pick('mode'), lco: pick('lco'), dept: pick('dept'),
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }), [toggleValue]);

  const base = basis === 'po' ? kpi.po : kpi.total;
  const baseName = basis === 'po' ? 'PO' : 'PO + POC';
  const compare = !hasFilters;
  const compareAll = compare && basis === 'po';
  const ref = reference || {};
  const cards = [
    { label: 'Total User Connectivity', value: kpi.total, tone: 'primary', icon: 'users', info: 'Household, Private Enterprise and GI-Enterprise connections with PO Status PO or POC', pct: pct(kpi.total, rows.length), pctOf: 'of all records', reference: ref.total, showReference: compare },
    { label: 'PO Count', value: kpi.po, tone: 'primary', icon: 'layers', info: 'PO Status = PO', pct: pct(kpi.po, kpi.total), pctOf: 'of total', reference: ref.po, showReference: compare },
    { label: 'POC Count', value: kpi.poc, tone: 'violet', icon: 'repeat', info: 'PO Status = POC', pct: pct(kpi.poc, kpi.total), pctOf: 'of total', reference: ref.poc, showReference: compare },
    { label: 'Lit-Up', value: kpi.lit, tone: 'good', icon: 'zap', info: `${baseName} records with Litup = Yes`, pct: pct(kpi.lit, base), pctOf: `of ${baseName}`, reference: ref.litUp, showReference: compareAll },
    { label: 'Yet to Lit-Up', value: kpi.yet, tone: 'warn', icon: 'clock', info: `${baseName} records with Litup = No or blank`, pct: pct(kpi.yet, base), pctOf: `of ${baseName}`, reference: ref.yetToLitUp, showReference: compareAll },
    { label: 'Service Provisioned', value: kpi.sp, tone: 'good', icon: 'check', info: 'Lit-Up records with Service Provisioned = Yes or Disconnected', pct: pct(kpi.sp, kpi.lit), pctOf: 'of Lit-Up', reference: ref.serviceProvisioned, showReference: compareAll },
    { label: 'Service Yet to Provision', value: kpi.spYet, tone: 'warn', icon: 'hourglass', info: 'Lit-Up minus Service Provisioned', pct: pct(kpi.spYet, kpi.lit), pctOf: 'of Lit-Up', reference: ref.serviceYetToProvision, showReference: compareAll },
    { label: 'SAC Form Received', value: kpi.sac, tone: 'good', icon: 'file', info: `SAC Form Status: ${config.sacReceived.join(', ')}`, pct: pct(kpi.sac, kpi.sp), pctOf: 'of Provisioned', reference: ref.sacReceived, showReference: compareAll },
    { label: 'SAC Form Yet to Receive', value: kpi.sacYet, tone: 'warn', icon: 'filePending', info: 'Service Provisioned minus SAC Form Received', pct: pct(kpi.sacYet, kpi.sp), pctOf: 'of Provisioned', reference: ref.sacYetToReceive, showReference: compareAll },
    { label: 'Disconnected', value: kpi.dis, tone: 'bad', icon: 'unplug', info: `${baseName} records with Disconnection Status = Yes`, pct: pct(kpi.dis, base), pctOf: `of ${baseName}`, reference: ref.disconnected, showReference: compareAll },
  ];

  const steps = useMemo(() => {
    const v = [[`${baseName}`, base], ['Lit-Up', kpi.lit], ['Service Provisioned', kpi.sp], ['SAC Received', kpi.sac]];
    return v.map(([name, value], i) => ({ name, value, conv: i && v[i - 1][1] ? +((value / v[i - 1][1]) * 100).toFixed(1) : null }));
  }, [baseName, base, kpi.lit, kpi.sp, kpi.sac]);

  const recon = useMemo(() => {
    if (!reference) return [];
    const b = computeKpis(rows, 'po', sacSet);
    return [
      ['Total user connectivity', b.total, reference.total, 'PO + POC in the 3 categories'],
      ['PO', b.po, reference.po, 'PO Status = PO'],
      ['POC', b.poc, reference.poc, 'PO Status = POC'],
      ['Lit-Up', b.lit, reference.litUp, 'PO and Litup = Yes'],
      ['Yet to Lit-Up', b.yet, reference.yetToLitUp, 'PO and Litup = No / blank'],
      ['Service Provisioned', b.sp, reference.serviceProvisioned, 'PO, Lit-Up, Provisioned = Yes / Disconnected'],
      ['Service Yet to Provision', b.spYet, reference.serviceYetToProvision, 'Lit-Up − Service Provisioned'],
      ['SAC Form Received', b.sac, reference.sacReceived, 'Status mapping pending business confirmation'],
      ['SAC Form Yet to Receive', b.sacYet, reference.sacYetToReceive, 'Service Provisioned − SAC Received'],
      ['Disconnected', b.dis, reference.disconnected, 'PO and Disconnection Status = Yes'],
    ];
  }, [rows, reference]);

  const excludedText = Object.entries(excluded.reasons).map(([r, n]) => `${fmt(n)} with ${r}`).join('; ');
  const scopeTip = `${fmt(rows.length)} of ${fmt(totalSource)} source records are PO or POC in the three categories${excluded.count ? ` (excluded: ${excludedText})` : ''}`;
  const empty = filtered.length === 0;
  const contextText = `As on ${config.asOfLabel}${hasFilters ? ` · Filters: ${activeChips.map((c) => `${c.label} = ${c.value}`).join('; ')}` : ' · All data'}`;

  return (
    <div className="app">
      <TooltipLayer />
      <header className="topbar">
        <div className="topbar-in">
          <div className="brand">
            <span className="mark">TF</span>
            <div>
              <h1>T-Fiber Connectivity Dashboard</h1>
              <p>End-user connections · as on {config.asOfLabel}</p>
            </div>
          </div>
          <div className="topbar-meta">
            <div className="seg dark" role="group" aria-label="Basis for Lit-Up to Disconnected figures">
              <button className={basis === 'po' ? 'on' : ''} onClick={() => setBasis('po')} data-tip="Matches the 16-Sep summary">PO only</button>
              <button className={basis === 'all' ? 'on' : ''} onClick={() => setBasis('all')}>PO + POC</button>
            </div>
            <span className="pill" data-tip={scopeTip} >{fmt(filtered.length)} / {fmt(rows.length)} records <span className="info light">i</span></span>
          </div>
        </div>
      </header>

      <main className="wrap">
        <section className="filterbar" aria-label="Filters">
          <div className="filterbar-row">
            <button className={`btn filter-toggle${showFilters ? ' open' : ''}`} onClick={() => setShowFilters((v) => !v)} aria-expanded={showFilters}>
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M3 5h18M6 12h12M10 19h4" /></svg>
              Filters{hasFilters && <span className="count">{activeChips.length}</span>}
            </button>
            <div className="chips">
              {activeChips.length === 0 && <span className="muted">All data · click any bar or slice to filter</span>}
              {activeChips.map((c) => (
                <button key={`${c.key}:${c.value}`} className="chip" onClick={() => toggleValue(c.key, c.value)} data-tip="Remove filter">
                  <b>{c.label}</b> {c.value} <span aria-hidden="true">×</span>
                </button>
              ))}
            </div>
            <button className="btn ghost" disabled={!hasFilters} onClick={() => setFilters(EMPTY)}>Reset</button>
          </div>
          {showFilters && (
            <div className="filters-grid">
              {FILTERS.map((f) => <MultiSelect key={f.key} label={f.label} options={options[f.key]} selected={filters[f.key]} onChange={(v) => setFilter(f.key, v)} />)}
            </div>
          )}
        </section>

        {missingColumns.length > 0 && <div className="notice">Columns not found in the data file: {missingColumns.join(', ')}</div>}

        {empty ? (
          <div className="card empty"><h2>No Data Available</h2><button className="btn primary" onClick={() => setFilters(EMPTY)}>Reset filters</button></div>
        ) : (
          <section className="kpis" aria-label="Key figures">
            {cards.map((c) => <KpiCard key={c.label} {...c} />)}
          </section>
        )}

        <nav className="tabs" role="tablist">
          {TABS.map((t) => <button key={t} role="tab" aria-selected={tab === t} className={tab === t ? 'on' : ''} onClick={() => setTab(t)}>{t}</button>)}
        </nav>

        {empty && tab !== 'Validation' && tab !== 'Records' ? null : (
          <>
            {tab === 'Overview' && (
              <div className="grid">
                <ChartCard className="span-7" title="Rollout pipeline"><PipelineChart steps={steps} /></ChartCard>
                <ChartCard className="span-5" title="PO vs POC"><DonutChart data={agg.po} centreLabel="PO + POC" colors={PO_COLORS} onPick={pickers.po} /></ChartCard>

                <ChartCard className="span-4" title="Connection category"><PoStackColumn data={agg.catPo} onPick={pickers.cat} /></ChartCard>
                <ChartCard className="span-4" title="Package"><DonutChart data={agg.pkg} centreLabel="connections" onPick={pickers.pkg} /></ChartCard>
                <ChartCard className="span-4" title="LCO / MSI / TSP"><DonutChart data={agg.lco} centreLabel="connections" onPick={pickers.lco} /></ChartCard>

                <ChartCard className="span-4" title="Solution type"><ColumnChart data={agg.sol} onPick={pickers.sol} /></ChartCard>
                <ChartCard className="span-4" title="Delivery mode"><HBarChart data={agg.mode.slice(0, 8)} color="#7c3aed" rowHeight={30} onPick={pickers.mode} /></ChartCard>
                <ChartCard className="span-4" title="SAC form status"><HBarChart data={agg.sac.slice(0, 8)} color="#0ea5e9" rowHeight={30} /></ChartCard>

                <ChartCard className="span-6" title="Top 8 districts · Lit-Up status"><LitStackChart data={agg.districtStack.slice(0, 8)} onPick={pickers.district} /></ChartCard>
                <ChartCard className="span-6" title="Top 8 departments · Lit-Up status"><LitStackChart data={agg.deptStack.slice(0, 8)} onPick={pickers.dept} /></ChartCard>
              </div>
            )}

            {tab === 'Geography' && (
              <div className="grid">
                <ChartCard className="span-7" title={`All districts · Lit-Up status (${agg.districtStack.length})`}>
                  <LitStackChart data={agg.districtStack} onPick={pickers.district} rowHeight={24} />
                </ChartCard>
                <ChartCard className="span-5" title="District ranking">
                  <DataTable rows={agg.districtStack} nameLabel="District" searchPlaceholder="Search district…" maxHeight={640} />
                </ChartCard>
              </div>
            )}

            {tab === 'Operators' && (
              <div className="grid">
                <ChartCard className="span-6" title="Top 15 LCO operators · Lit-Up status">
                  <LitStackChart data={agg.operators.slice(0, 15)} onPick={pickers.op} rowHeight={26} />
                  <p className="foot-note">Not charted: {Object.entries(agg.operatorExcluded).map(([n, c]) => `${n} ${fmt(c)}`).join(' · ')}</p>
                </ChartCard>
                <ChartCard className="span-6" title={`Operator ranking (${fmt(agg.operators.length)})`}>
                  <DataTable rows={agg.operators} nameLabel="Operator" searchPlaceholder="Search operator…" maxHeight={560} />
                </ChartCard>
              </div>
            )}

            {tab === 'Records' && <RecordsTable rows={filtered} context={contextText} />}

            {tab === 'Validation' && reference && (
              <ChartCard title="Reconciliation with Summary 16-Sep-2026">
                <div className="table-wrap flat">
                  <table className="recon">
                    <thead><tr><th>Metric</th><th>Rule</th><th>Dashboard</th><th>Summary</th><th>Status</th></tr></thead>
                    <tbody>
                      {recon.map(([m, a, b, rule]) => (
                        <tr key={m}><td>{m}</td><td className="muted">{rule}</td><td>{fmt(a)}</td><td>{fmt(b)}</td>
                          <td>{a === b ? <span className="badge ok">✓ Match</span> : <span className="badge warn">{a - b > 0 ? '+' : ''}{fmt(a - b)}</span>}</td></tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <p className="foot-note">{scopeTip}.</p>
              </ChartCard>
            )}
          </>
        )}
      </main>
    </div>
  );
}
